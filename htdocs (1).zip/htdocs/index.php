<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Департамент лесного хозяйства</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php
echo "<h1>Добро пожаловать на сайт департамента лесного хозяйства</h1>";
echo "<p><a href='login.php'>Войти</a></p>";
?>


<button onclick="toggleVision()" class="vision-btn">
Версия для слабовидящих
</button>

<script>
function toggleVision() {
    document.body.classList.toggle("vision");
}
</script>
<nav>
    <a href="index.php">Главная</a>
    <a href="about.php">О нас</a>
    <a href="services.php">Услуги</a>
    <a href="news.php">Новости</a>
    <a href="contact.php">Контакты</a>
    <a href="sitemap.php">Карта сайта</a>
</nav>

</body>
</html>
