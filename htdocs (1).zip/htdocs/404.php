<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Страница не найдена</title>
<link rel="stylesheet" href="/style.css">
</head>
<body>
    <h1>404 — Страница не найдена</h1>
    <p>Извините, страница, которую вы ищете, не существует.</p>
    <a href="index.php">Вернуться на главную</a>
</body>
</html>
