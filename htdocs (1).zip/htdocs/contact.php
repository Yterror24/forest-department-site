<?php
echo "<h1>Контакты департамента лесного хозяйства</h1>";
echo "<p>Адрес, телефон, email.</p>";
?>
<link rel="stylesheet" href="style.css">
<script src="vision.js"></script>

<button onclick="toggleVision()" class="vision-btn">
    Версия для слабовидящих
</button>
