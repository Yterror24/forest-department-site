<?php
echo "<h1>Информация о нас</h1>";
echo "<p>Кто мы мы и что делаем</p>";
?>
<link rel="stylesheet" href="style.css">
<script src="vision.js"></script>

<button onclick="toggleVision()" class="vision-btn">
    Версия для слабовидящих
</button>
