<?php
echo "<h1>Карта сайта департамента лесного хозяйства</h1>";
echo "<ul>
        <li><a href='index.php'>Главная</a></li>
        <li><a href='about.php'>О департаменте</a></li>
        <li><a href='services.php'>Услуги</a></li>
        <li><a href='news.php'>Новости</a></li>
        <li><a href='contact.php'>Контакты</a></li>
        <li><a href='login.php'>Вход</a></li>
      </ul>";
?>
<link rel="stylesheet" href="style.css">
<script src="vision.js"></script>

<button onclick="toggleVision()" class="vision-btn">
    Версия для слабовидящих
</button>
