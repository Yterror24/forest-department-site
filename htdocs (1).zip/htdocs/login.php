<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $_SESSION['username'] = $username;
        echo "Вы вошли как $username";
        echo "<br><a href='index.php'>На главную</a>";
    } else {
        echo "Неверный логин или пароль";
    }
} else {
?>
<form method="POST">
    Логин: <input type="text" name="username"><br>
    Пароль: <input type="password" name="password"><br>
    <input type="submit" value="Войти">
</form>
<?php
}
?>
<link rel="stylesheet" href="style.css">
<script src="vision.js"></script>

<button onclick="toggleVision()" class="vision-btn">
    Версия для слабовидящих
</button>
