function toggleVision() {
    document.body.classList.toggle("vision");
}
