<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "sql211.infinityfree.com";    
$username = "if0_40572069";               
$password = "240210Kiv";          
$dbname = "if0_40572069_users_db";          

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
